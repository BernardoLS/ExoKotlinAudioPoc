package com.example.exokotlinaudiopoc

object C {
    const val PLAYBACK_CHANNEL_ID = "playback_channel"
    const val PLAYBACK_NOTIFICATION_ID = 1
    const val MEDIA_SESSION_TAG = "audio_demo"
    const val DOWNLOAD_CHANNEL_ID = "download_channel"
    const val DOWNLOAD_NOTIFICATION_ID = 2
}